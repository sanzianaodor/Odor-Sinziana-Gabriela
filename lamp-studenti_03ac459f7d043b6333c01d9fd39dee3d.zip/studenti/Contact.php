<?php
session_start();
$timp_limita = 3600; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timp_limita)) {
    session_unset(); session_destroy(); header("Location: login.html"); exit;
}
$_SESSION['last_activity'] = time();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Contact - Casa cu Delicii</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<a id="top"></a>

<header>
    <div class="container">
        <h1 class="logo">Casa cu Delicii</h1>
        <nav>
            <ul>
                <li><a href="index.php">Acasă</a></li>
                <li><a href="Meniu.php">Meniu</a></li>
                <li><a href="Rezervari.php">Rezervări</a></li>
                <li><a href="Despre.php">Despre</a></li>
                <li><a href="Contact.php" class="active">Contact</a></li>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="login-item"><a href="profil.php" class="btn-login" style="background:#8b4513; color:white!important;">Contul Meu</a></li>
                <?php elseif (isset($_SESSION['admin'])): ?>
                    <li class="login-item"><a href="admin.php" class="btn-login" style="background:#8b4513; color:white!important;">Contul Meu</a></li>
                <?php else: ?>
                    <li class="login-item"><a href="login.html" class="btn-login">Login / Înregistrare</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>

<main class="contact-page">
    <div class="container contact-card">
        <h1>Contactează-ne</h1>
        <p><strong>Telefon:</strong> 0723 456 789</p>
        <p><strong>Email:</strong> contact@casacudelicii.ro</p>
        <p><strong>Adresă:</strong> Str. Mioriței nr. 12, București</p>

        <h2>Trimite-ne un mesaj</h2>
        
        <form class="contact-form" id="formularContact" action="api_contact.php" method="post">
            <label for="name">Nume complet:</label>
            <input type="text" id="name" name="nume" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="subject">Subiect:</label>
            <input type="text" id="subject" name="subject">

            <label for="message">Mesaj:</label>
            <textarea id="message" name="message" rows="5" required></textarea>

            <button type="submit">Trimite mesajul</button>
            
            <p id="statusContact" style="margin-top: 15px; font-weight: bold; text-align:center;"></p>
        </form>
    </div>
</main>

<aside>
    <h3>Program și locație</h3>
    <ul>
        <li> Luni - Duminică: 10:00 - 23:00</li>
        <li> București, Str. Mioriței nr. 12</li>
        <li> 0723456789</li>
    </ul>
</aside>

<footer>
    <p>&copy; 2025 Casa cu Delicii — Toate drepturile rezervate</p>
</footer>

<a href="#top" class="back-to-top">⬆ Sus</a>

<script src="script.js"></script>
<script src="script_contact.js"></script> 
</body>
</html>