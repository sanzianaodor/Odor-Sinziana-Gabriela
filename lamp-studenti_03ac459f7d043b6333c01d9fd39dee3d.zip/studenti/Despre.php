<?php
session_start();
$timp_limita = 3600; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timp_limita)) {
    session_unset(); session_destroy(); header("Location: login.html"); exit;
}
$_SESSION['last_activity'] = time();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Despre - Casa cu Delicii</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<a id="top"></a>

<header>
    <div class="container">
        <h1 class="logo">Casa cu Delicii</h1>
        <nav>
    <ul>
        <li><a href="index.php">Acasă</a></li>
        <li><a href="Meniu.php">Meniu</a></li>
        <li><a href="Rezervari.php">Rezervări</a></li>
        <li><a href="Despre.php">Despre</a></li>
        <li><a href="Contact.php">Contact</a></li>

        <?php if (isset($_SESSION['user_id'])): ?>
            <li class="login-item">
                <a href="profil.php" class="btn-login" style="background:#8b4513; color:white!important;">
                    Contul Meu
                </a>
            </li>
        <?php elseif (isset($_SESSION['admin'])): ?>
            <li class="login-item">
                <a href="admin.php" class="btn-login" style="background:#8b4513; color:white!important;">
                    Contul Meu
                </a>
            </li>
        <?php else: ?>
            <li class="login-item">
                <a href="login.html" class="btn-login">
                    Login / Înregistrare
                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>
    </div>
</header>

<main class="about">
    <div class="container about-card">
        <h1>Despre Restaurantul Casa cu Delicii</h1>
        <p>Restaurantul <strong>Casa cu Delicii</strong> combină tradiția culinară românească cu eleganța modernă. Situat în centrul Bucureștiului, oferim o experiență gastronomică de neuitat.</p>
        <p>Folosim doar ingrediente proaspete, locale, pentru a crea preparate delicioase și sănătoase.</p>
        <p>Atmosfera caldă și personalul prietenos fac din fiecare vizită o experiență memorabilă.</p>
    </div>
</main>

<aside>
    <h3>De ce să ne alegi?</h3>
    <ul>
        <li> Ingrediente proaspete locale</li>
        <li> Bucătari cu experiență</li>
        <li> Ambianță plăcută</li>
    </ul>
</aside>

<footer>
    <p>&copy; 2025 Casa cu Delicii — Toate drepturile rezervate</p>
</footer>

<a href="#top" class="back-to-top">⬆ Sus</a>
<script src="script.js"></script>
</body>
</html>