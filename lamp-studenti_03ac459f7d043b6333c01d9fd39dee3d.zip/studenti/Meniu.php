<?php
session_start();
$timp_limita = 3600; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timp_limita)) {
    session_unset(); session_destroy(); header("Location: login.html"); exit;
}
$_SESSION['last_activity'] = time();

// CONEXIUNE BAZA DE DATE 
$host = "mysql"; $db = "studenti"; $user = "user"; $pass = "password";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Eroare conexiune BD"); }

// EXTRAGERE PRODUSE 
$stmt = $pdo->query("SELECT * FROM produse");
$produse = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Le sortam pe categorii în array-uri separate
$antreuri = [];
$feluri_principale = [];
$deserturi = [];

foreach ($produse as $produs) {
    if ($produs['categorie'] == 'antreu') {
        $antreuri[] = $produs;
    } elseif ($produs['categorie'] == 'fel_principal') {
        $feluri_principale[] = $produs;
    } elseif ($produs['categorie'] == 'desert') {
        $deserturi[] = $produs;
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Meniu - Casa cu Delicii</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<a id="top"></a>

<header>
    <div class="container">
        <h1 class="logo">Casa cu Delicii</h1>
        <nav>
            <ul>
                <li><a href="index.php">Acasă</a></li>
                <li><a href="Meniu.php" class="active">Meniu</a></li>
                <li><a href="Rezervari.php">Rezervări</a></li>
                <li><a href="Despre.php">Despre</a></li>
                <li><a href="Contact.php">Contact</a></li>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="login-item"><a href="profil.php" class="btn-login" style="background:#8b4513; color:white!important;">Contul Meu</a></li>
                <?php elseif (isset($_SESSION['admin'])): ?>
                    <li class="login-item"><a href="admin.php" class="btn-login" style="background:#8b4513; color:white!important;">Contul Meu</a></li>
                <?php else: ?>
                    <li class="login-item"><a href="login.html" class="btn-login">Login / Înregistrare</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>

<main class="menu">
    <div class="container">
        <h1>Meniul Restaurantului</h1>

        <h2>Antreuri</h2>
        <div class="menu-grid">
            <?php foreach ($antreuri as $p): ?>
                <div class="menu-card">
                    <img src="<?= htmlspecialchars($p['imagine']) ?>" alt="<?= htmlspecialchars($p['nume']) ?>">
                    <h3><?= htmlspecialchars($p['nume']) ?></h3>
                    <p><?= $p['pret'] ?> lei</p>
                </div>
            <?php endforeach; ?>
        </div>

        <h2>Feluri principale</h2>
        <div class="menu-grid">
            <?php foreach ($feluri_principale as $p): ?>
                <div class="menu-card">
                    <img src="<?= htmlspecialchars($p['imagine']) ?>" alt="<?= htmlspecialchars($p['nume']) ?>">
                    <h3><?= htmlspecialchars($p['nume']) ?></h3>
                    <p><?= $p['pret'] ?> lei</p>
                </div>
            <?php endforeach; ?>
        </div>

        <h2>Deserturi</h2>
        <div class="menu-grid">
            <?php foreach ($deserturi as $p): ?>
                <div class="menu-card">
                    <img src="<?= htmlspecialchars($p['imagine']) ?>" alt="<?= htmlspecialchars($p['nume']) ?>">
                    <h3><?= htmlspecialchars($p['nume']) ?></h3>
                    <p><?= $p['pret'] ?> lei</p>
                </div>
            <?php endforeach; ?>
        </div>

    </div>
</main>

<aside>
    <h3>Recomandări ale bucătarului</h3>
    <ul>
        <li> Paste Carbonara — preparat preferat de clienți</li>
        <li> Somon la cuptor — servit cu sos de lămâie</li>
        <li> Cheesecake — desertul vedetă al casei</li>
    </ul>
</aside>

<footer>
    <p>&copy; 2025 Casa cu Delicii — Toate drepturile rezervate</p>
</footer>

<a href="#top" class="back-to-top">⬆ Sus</a>
<script src="script.js"></script>
</body>
</html>