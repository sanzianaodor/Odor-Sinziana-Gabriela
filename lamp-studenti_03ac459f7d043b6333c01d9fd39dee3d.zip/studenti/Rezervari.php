<?php
session_start();
$timp_limita = 3600; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timp_limita)) {
    session_unset(); session_destroy(); header("Location: login.html"); exit;
}
$_SESSION['last_activity'] = time();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Rezervări - Casa cu Delicii</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<a id="top"></a>

<header>
    <div class="container">
        <h1 class="logo">Casa cu Delicii</h1>
        <nav>
            <ul>
                <li><a href="index.php">Acasă</a></li>
                <li><a href="Meniu.php">Meniu</a></li>
                <li><a href="Rezervari.php" class="active">Rezervări</a></li>
                <li><a href="Despre.php">Despre</a></li>
                <li><a href="Contact.php">Contact</a></li>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="login-item"><a href="profil.php" class="btn-login" style="background:#8b4513; color:white!important;">Contul Meu</a></li>
                <?php elseif (isset($_SESSION['admin'])): ?>
                    <li class="login-item"><a href="admin.php" class="btn-login" style="background:#8b4513; color:white!important;">Contul Meu</a></li>
                <?php else: ?>
                    <li class="login-item"><a href="login.html" class="btn-login">Login / Înregistrare</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>

<main class="reservation">
    <div class="container">
        <h1>Rezervări la Casa cu Delicii</h1>
        <p style="text-align:center; margin-bottom: 30px;">Completează formularul pentru a-ți rezerva masa.</p>

        <div class="reservation-card">
            <form id="formularRezervareClient" action="api_rezervare.php" method="POST">
                
                <label for="name">Nume complet:</label>
                <input type="text" id="name" name="nume" required value="<?= isset($_SESSION['user_nume']) ? htmlspecialchars($_SESSION['user_nume']) : '' ?>"> 

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="phone">Telefon:</label>
                <input type="tel" id="phone" name="telefon" required>

                <label for="date">Data rezervării:</label>
                <input type="date" id="date" name="data_rezervare_raw" required> 
                
                <label for="time">Ora:</label>
                <input type="time" id="time" name="ora_rezervare_raw" required>

                <label for="guests">Număr de persoane:</label>
                <select id="guests" name="numar_persoane" required onchange="verificaGrup()">
                    <option value="">Selectează</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6+">6+</option>
                </select>

                <p id="info_grup_mare" style="display:none; color: #d63031; font-weight: bold; margin-top: 10px; font-size: 0.9em;">
                    ℹ️ Pentru grupurile mai mari de 6 persoane, veți fi contactat telefonic pentru stabilirea detaliilor.
                </p>

                <button type="submit" style="margin-top: 20px;">Rezervă acum</button>
                
                <p id="statusRezervare" style="margin-top: 15px; font-weight: bold; text-align:center;"></p>
            </form>
        </div>
    </div>
</main>

<aside>
    <h3>Informații utile</h3>
    <ul>
        <li> Rezervările telefonice se fac între 10:00 - 22:00</li>
        <li> Pentru grupuri mari, recomandăm rezervare cu 24h înainte</li>
        <li> Oferim meniuri speciale pentru evenimente</li>
    </ul>
</aside>

<footer>
    <p>&copy; 2025 Casa cu Delicii — Toate drepturile rezervate</p>
</footer>

<a href="#top" class="back-to-top">⬆ Sus</a>

<script src="script.js"></script>
<script src="script_conexiune.js"></script>

<script>
function verificaGrup() {
    var select = document.getElementById("guests");
    var mesaj = document.getElementById("info_grup_mare");
    
    if (select.value === "6+") {
        mesaj.style.display = "block";
    } else {
        mesaj.style.display = "none";
    }
}
</script>

</body>
</html>