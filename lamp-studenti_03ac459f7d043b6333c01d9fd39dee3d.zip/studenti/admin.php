<?php
session_start();

// 1. AUTO-LOGOUT
$timp_limita = 3600; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timp_limita)) {
    session_unset(); session_destroy(); header("Location: login.html"); exit;
}
$_SESSION['last_activity'] = time();

// 2. VERIFICARE ADMIN
if (!isset($_SESSION["admin"])) {
    header("Location: login.html");
    exit;
}

$host = "mysql"; $db = "studenti"; $user = "user"; $pass = "password";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Err"); }

// ACTIUNI

if (isset($_GET['status_id']) && isset($_GET['new_status'])) {
    $stmt = $pdo->prepare("UPDATE rezervari SET status = ? WHERE id = ?");
    $stmt->execute([$_GET['new_status'], $_GET['status_id']]);
    header("Location: admin.php"); exit;
}

if (isset($_GET['sterge_id'])) {
    $stmt = $pdo->prepare("DELETE FROM rezervari WHERE id = ?");
    $stmt->execute([$_GET['sterge_id']]);
    header("Location: admin.php"); exit;
}

if (isset($_GET['sterge_mesaj_id'])) {
    $stmt = $pdo->prepare("DELETE FROM mesaje WHERE id = ?");
    $stmt->execute([$_GET['sterge_mesaj_id']]);
    header("Location: admin.php"); exit;
}

// CALCUL STATISTICI 
$stmtAzi = $pdo->query("SELECT COUNT(*) FROM rezervari WHERE DATE(data_rezervare) = CURDATE()");
$rezervariAzi = $stmtAzi->fetchColumn();

$stmtPers = $pdo->query("SELECT SUM(numar_persoane) FROM rezervari WHERE DATE(data_rezervare) = CURDATE() AND status != 'Anulat'");
$oaspetiAzi = $stmtPers->fetchColumn() ?: 0; 

$stmtMsgCount = $pdo->query("SELECT COUNT(*) FROM mesaje");
$totalMesaje = $stmtMsgCount->fetchColumn();

// PRELUARE DATE (SEPARAT PE DOUA CATEGORII)

// 1. REZERVARI ACTIVE (Azi și Viitor) - Ordonate Crescator (cele mai apropiate primele)
$stmtActive = $pdo->query("SELECT * FROM rezervari WHERE data_rezervare >= CURDATE() ORDER BY data_rezervare ASC, ora_rezervare ASC");
$rezervariActive = $stmtActive->fetchAll(PDO::FETCH_ASSOC);

// 2. ISTORIC (Trecute) - Ordonate Descrescător (cele mai recente trecute primele)
$stmtIstoric = $pdo->query("SELECT * FROM rezervari WHERE data_rezervare < CURDATE() ORDER BY data_rezervare DESC, ora_rezervare DESC");
$rezervariIstoric = $stmtIstoric->fetchAll(PDO::FETCH_ASSOC);

// 3. MESAJE
$stmtMsg = $pdo->query("SELECT * FROM mesaje ORDER BY data_trimitere DESC");
$mesaje = $stmtMsg->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Statistici</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
    <style>
        .separator { margin: 60px 0 20px 0; border-top: 2px dashed #8b4513; opacity: 0.3; }
        h2.admin-subtitle { color: #8b4513; margin-bottom: 20px; font-family: 'Cinzel', serif; }
        
        .status-badge { padding: 5px 10px; border-radius: 15px; font-size: 0.85em; font-weight: bold; color: white; display: inline-block; }
        .status-asteptare { background-color: #f39c12; } 
        .status-confirmat { background-color: #27ae60; } 
        .status-anulat    { background-color: #c0392b; }
        
        .btn-small { padding: 3px 8px; font-size: 0.8em; border-radius: 4px; text-decoration: none; color: white; margin-right: 3px; }
        .btn-approve { background-color: #27ae60; }
        .btn-reject { background-color: #c0392b; }

        /* Stil pentru tabelul de istoric */
        .table-istoric td { color: #777; background-color: #f9f9f9; }
    </style>
</head>
<body>

<header>
    <div class="container">
        <h1 class="logo">Panou Administrare</h1>
        <nav>
            <ul>
                <li><a href="index.php">Vezi Site</a></li>
                <li><a href="admin_meniu.php">Gestionează Meniul</a></li>
                <li><a href="Rezervari.php">Adaugă Rezervare</a></li>
                <li class="login-item"><a href="logout.php" class="btn-login">Delogare</a></li>
            </ul>
        </nav>
    </div>
</header>

<main>
    <div class="container reservation-card" style="max-width: 1200px;">
        
        <h1 class="admin-subtitle">Sumar Activitate Astăzi</h1>
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Rezervări Astăzi</th>
                        <th>Oaspeți Așteptați</th>
                        <th>Mesaje Clienți</th>
                        <th>Capacitate Totală</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?= $rezervariAzi ?></td>
                        <td><?= $oaspetiAzi ?></td>
                        <td><?= $totalMesaje ?></td>
                        <td style="color: #27ae60; font-weight:bold;">40 locuri</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="separator"></div>

        <h1 class="admin-subtitle">Rezervări Active (Viitoare)</h1>
        
        <?php if (count($rezervariActive) > 0): ?>
            <div style="overflow-x:auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Nr.</th>
                            <th>Nume</th>
                            <th>Data & Ora</th>
                            <th>Pers.</th>
                            <th>Telefon</th>
                            <th>Status</th>
                            <th>Acțiuni</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $nr_rez = 1; foreach ($rezervariActive as $r): 
                            $statusClass = 'status-asteptare';
                            if($r['status'] == 'Confirmat') $statusClass = 'status-confirmat';
                            if($r['status'] == 'Anulat') $statusClass = 'status-anulat';
                        ?>
                        <tr style="border-left: 5px solid #27ae60;"> <td><?= $nr_rez++ ?></td>
                            <td><?= htmlspecialchars($r['nume']) ?></td>
                            <td>
                                <strong><?= date('d.m.Y', strtotime($r['data_rezervare'])) ?></strong><br>
                                <?= date('H:i', strtotime($r['ora_rezervare'])) ?>
                            </td>
                            <td><?= $r['numar_persoane'] ?></td>
                            <td><?= htmlspecialchars($r['telefon']) ?></td>
                            <td><span class="status-badge <?= $statusClass ?>"><?= $r['status'] ?></span></td>
                            <td>
                                <a href="admin.php?status_id=<?= $r['id'] ?>&new_status=Confirmat" class="btn-small btn-approve">✔</a>
                                <a href="admin.php?status_id=<?= $r['id'] ?>&new_status=Anulat" class="btn-small btn-reject">✖</a>
                            </td>
                            <td>
                                <a href="edit_rezervare.php?id=<?= $r['id'] ?>" style="color:blue;">Edit</a> | 
                                <a href="admin.php?sterge_id=<?= $r['id'] ?>" style="color:red;" onclick="return confirm('Ștergi?')">Șterge</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p>Nu ai rezervări viitoare.</p>
        <?php endif; ?>

        <div class="separator"></div>

        <h1 class="admin-subtitle" style="color: #7f8c8d;">Istoric Rezervări (Trecute)</h1>
        
        <?php if (count($rezervariIstoric) > 0): ?>
            <div style="overflow-x:auto;">
                <table class="admin-table table-istoric">
                    <thead>
                        <tr style="background-color: #95a5a6;"> <th>Nr.</th>
                            <th>Nume</th>
                            <th>Data (Trecută)</th>
                            <th>Status Final</th>
                            <th>Acțiuni</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $nr_ist = 1; foreach ($rezervariIstoric as $r): ?>
                        <tr>
                            <td><?= $nr_ist++ ?></td>
                            <td><?= htmlspecialchars($r['nume']) ?></td>
                            <td><?= date('d.m.Y', strtotime($r['data_rezervare'])) ?></td>
                            <td><?= $r['status'] ?></td>
                            <td>
                                <a href="admin.php?sterge_id=<?= $r['id'] ?>" style="color:red; font-size:0.9em;" onclick="return confirm('Ștergi din istoric?')">Șterge Definitiv</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p style="color:gray;">Istoricul este gol.</p>
        <?php endif; ?>

        <div class="separator"></div>

        <h1 class="admin-subtitle">Mesaje Clienți</h1>
        <?php if (count($mesaje) > 0): ?>
            <div style="overflow-x:auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Nr.</th>
                            <th>Data</th>
                            <th>Nume</th>
                            <th>Mesaj</th>
                            <th>Acțiune</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $nr_msg = 1; foreach ($mesaje as $m): ?>
                        <tr>
                            <td><?= $nr_msg++ ?></td>
                            <td><?= date('d.m H:i', strtotime($m['data_trimitere'])) ?></td>
                            <td><?= htmlspecialchars($m['nume']) ?><br><small><?= htmlspecialchars($m['email']) ?></small></td>
                            <td style="max-width: 400px;"><?= nl2br(htmlspecialchars($m['mesaj'])) ?></td>
                            <td><a href="admin.php?sterge_mesaj_id=<?= $m['id'] ?>" class="btn-del" onclick="return confirm('Ștergi?')">Șterge</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

    </div>
</main>
</body>
<a id="top"></a>
<footer>
    <p>&copy; 2025 Casa cu Delicii — Toate drepturile rezervate</p>
</footer>

<a href="#top" class="back-to-top">⬆ Sus</a>
</html>