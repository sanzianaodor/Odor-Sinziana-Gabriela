<?php
session_start();

// 1. AUTO-LOGOUT
$timp_limita = 3600; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timp_limita)) {
    session_unset(); session_destroy(); header("Location: login.html"); exit;
}
$_SESSION['last_activity'] = time();

// 2. VERIFICARE ADMIN
if (!isset($_SESSION["admin"])) {
    header("Location: login.html");
    exit;
}

// 3. CONEXIUNE BD
$host = "mysql"; $db = "studenti"; $user = "user"; $pass = "password";
try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Eroare conexiune BD"); }

// Extragem toate produsele
$stmt = $conn->query("SELECT * FROM produse ORDER BY categorie DESC, nume ASC");
$produse = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Gestionare Meniu - Admin</title>
    <link rel="stylesheet" href="style.css">
        <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
    <style>
        .produs-img-admin { width: 50px; height: 50px; object-fit: cover; border-radius: 5px; }
        .badge { padding: 5px 10px; border-radius: 15px; font-size: 0.8em; color: white; font-weight: bold; }
        .badge-antreu { background-color: #27ae60; }
        .badge-fel_principal { background-color: #d35400; }
        .badge-desert { background-color: #8e44ad; }
    </style>
</head>
<body>

<header>
    <div class="container">
        <h1 class="logo">Gestionare Meniu</h1>
        <nav>
            <ul>
                <li><a href="admin.php">← Înapoi la site</a></li>
                <li class="login-item"><a href="logout.php" class="btn-login">Delogare</a></li>
            </ul>
        </nav>
    </div>
</header>

<main>
    <div class="container reservation-card" style="max-width: 1000px;">
        <h1>Lista Preparatelor</h1>
        
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Imagine</th>
                        <th>Nume Preparat</th>
                        <th>Categorie</th>
                        <th>Preț (Lei)</th>
                        <th>Acțiune</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($produse as $p): ?>
                    <tr>
                        <td><img src="<?= htmlspecialchars($p['imagine']) ?>" class="produs-img-admin" alt=""></td>
                        <td><?= htmlspecialchars($p['nume']) ?></td>
                        <td>
                            <span class="badge badge-<?= $p['categorie'] ?>">
                                <?= strtoupper(str_replace('_', ' ', $p['categorie'])) ?>
                            </span>
                        </td>
                        <td style="font-weight:bold; color:#8b4513;"><?= $p['pret'] ?> lei</td>
                        <td>
                            <a href="edit_produs.php?id=<?= $p['id'] ?>" class="btn-edit">Editează Preț/Nume</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

</body>
<a id="top"></a>
<footer>
    <p>&copy; 2025 Casa cu Delicii — Toate drepturile rezervate</p>
</footer>

<a href="#top" class="back-to-top">⬆ Sus</a>
</html>