<?php
header("Content-Type: application/json");

// Configurare BD
$host = "mysql"; $db = "studenti"; $user = "user"; $pass = "password";

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["status" => "error", "mesaj" => "Eroare conexiune BD"]);
    exit;
}

// Preluare date
$nume    = trim($_POST["nume"] ?? "");
$email   = trim($_POST["email"] ?? "");
$subiect = trim($_POST["subject"] ?? ""); 
$mesaj   = trim($_POST["message"] ?? ""); 

// Validare 
if (!$nume || !$email || !$mesaj) {
    echo json_encode(["status" => "error", "mesaj" => "Te rugăm să completezi numele, emailul și mesajul!"]);
    exit;
}

try {
    // Inserare
    $stmt = $conn->prepare("INSERT INTO mesaje (nume, email, subiect, mesaj) VALUES (?, ?, ?, ?)");
    $stmt->execute([$nume, $email, $subiect, $mesaj]);
    
    echo json_encode(["status" => "success", "mesaj" => "Mesajul tău a fost trimis! Îți vom răspunde curând."]);

} catch (Exception $e) {
    echo json_encode(["status" => "error", "mesaj" => "Eroare la salvare: " . $e->getMessage()]);
}
?>