<?php
header("Content-Type: application/json");
session_start();

$host = "mysql"; $db = "studenti"; $user = "user"; $pass = "password";

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["status" => "error", "mesaj" => "Eroare conexiune BD"]);
    exit;
}

$nume    = trim($_POST["nume"] ?? "");
$email   = trim($_POST["email"] ?? "");
$telefon = trim($_POST["telefon"] ?? "");
$data    = $_POST["data_rezervare_raw"] ?? "";
$ora     = $_POST["ora_rezervare_raw"] ?? "";
$pers    = $_POST["numar_persoane"] ?? "";

if (!$nume || !$email || !$telefon || !$data || !$ora || !$pers) {
    echo json_encode(["status" => "error", "mesaj" => "Te rugăm să completezi toate câmpurile!"]);
    exit;
}

$persoane_noi = intval($pers); 
$userId = $_SESSION['user_id'] ?? null;
$limita_locuri = 40; 

try {
    // 1. VERIFICARE DUPLICAT
    $checkStmt = $conn->prepare("SELECT id FROM rezervari WHERE email = ? AND data_rezervare = ? AND ora_rezervare = ?");
    $checkStmt->execute([$email, $data, $ora]);
    if ($checkStmt->fetch()) {
        echo json_encode(["status" => "error", "mesaj" => "Există deja o rezervare pe acest email la această oră!"]);
        exit;
    }

    // 2. VERIFICARE CAPACITATE
    $sqlCapacitate = "SELECT SUM(CAST(numar_persoane AS UNSIGNED)) as total_ocupat 
                      FROM rezervari 
                      WHERE data_rezervare = :data 
                      AND ora_rezervare > SUBTIME(:ora, '02:00:00') 
                      AND ora_rezervare < ADDTIME(:ora, '02:00:00')";

    $stmtCap = $conn->prepare($sqlCapacitate);
    $stmtCap->execute([':data' => $data, ':ora' => $ora]);
    $rezultat = $stmtCap->fetch(PDO::FETCH_ASSOC);
    
    $locuri_ocupate = $rezultat['total_ocupat'] ? intval($rezultat['total_ocupat']) : 0;
    $locuri_disponibile = $limita_locuri - $locuri_ocupate;

    if ($locuri_ocupate + $persoane_noi > $limita_locuri) {
        if ($locuri_disponibile <= 0) {
            $mesaj_eroare = "Restaurantul este complet ocupat la această oră.";
        } else {
            $mesaj_eroare = "Nu mai sunt suficiente locuri! Mai sunt doar $locuri_disponibile locuri disponibile.";
        }
        echo json_encode(["status" => "error", "mesaj" => $mesaj_eroare]);
        exit;
    }

    // 3. INSERARE
    $stmt = $conn->prepare(
        "INSERT INTO rezervari (nume, email, telefon, data_rezervare, ora_rezervare, numar_persoane, user_id) 
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );

    $stmt->execute([$nume, $email, $telefon, $data, $ora, $pers, $userId]);
    
    // MESAJ FINAL PERSONALIZAT
    if ($pers === "6+") {
        $mesaj_succes = "Rezervare preluată! Te vom contacta telefonic pentru confirmarea detaliilor grupului.";
    } else {
        $mesaj_succes = "Rezervare confirmată! Te așteptăm cu drag.";
    }
    
    echo json_encode(["status" => "success", "mesaj" => $mesaj_succes]);

} catch (Exception $e) {
    echo json_encode(["status" => "error", "mesaj" => "Eroare la salvare: " . $e->getMessage()]);
}
?>