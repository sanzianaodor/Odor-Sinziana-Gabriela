<?php
session_start();
$host = "mysql"; $db = "studenti"; $user = "user"; $pass = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
} catch (PDOException $e) { die("Eroare BD"); }

$action = $_POST['action'] ?? '';

// 1. LOGIN 
if ($action === 'login') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // A. Verificam daca e ADMIN
    $stmt = $pdo->prepare("SELECT * FROM admini WHERE username = ?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && $password === $admin['parola']) {
        $_SESSION['admin'] = $admin['username'];
        header("Location: admin.php");
        exit;
    }

    // B. Verificam daca e UTILIZATOR 
    $stmt = $pdo->prepare("SELECT * FROM utilizatori WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Verificam parola criptata
    if ($user && password_verify($password, $user['parola'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_nume'] = $user['nume'];
        header("Location: profil.php"); // Mergem la pagina utilizatorului
        exit;
    }

    echo "Email sau parolă incorectă! <a href='login.html'>Încearcă din nou</a>";
}

// 2. LOGICA DE INREGISTRARE 
elseif ($action === 'register') {
    $nume = $_POST['nume'];
    $email = $_POST['email'];
    $passRaw = $_POST['password'];

    // Criptam parola pentru securitate
    $passHash = password_hash($passRaw, PASSWORD_DEFAULT);

    try {
        $stmt = $pdo->prepare("INSERT INTO utilizatori (nume, email, parola) VALUES (?, ?, ?)");
        $stmt->execute([$nume, $email, $passHash]);
        
        // Logam automat utilizatorul dupa inregistrare
        $_SESSION['user_id'] = $pdo->lastInsertId();
        $_SESSION['user_nume'] = $nume;
        
        header("Location: profil.php");
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Cod eroare pentru duplicat (email existent)
            echo "Acest email este deja folosit. <a href='login.html'>Înapoi</a>";
        } else {
            echo "Eroare: " . $e->getMessage();
        }
    }
}
?>