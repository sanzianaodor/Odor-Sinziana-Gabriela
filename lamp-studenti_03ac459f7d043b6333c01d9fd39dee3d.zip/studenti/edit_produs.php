<?php
session_start();

// Verificare Admin
if (!isset($_SESSION["admin"])) { header("Location: login.html"); exit; }

$host = "mysql"; $db = "studenti"; $user = "user"; $pass = "password";
try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Eroare"); }

$mesaj = "";
$produs = null;

// 1. SALVARE MODIFICARI 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $nume = $_POST['nume'];
    $pret = $_POST['pret'];
    
    // Validare 
    if ($nume && $pret) {
        $stmt = $conn->prepare("UPDATE produse SET nume = ?, pret = ? WHERE id = ?");
        if ($stmt->execute([$nume, $pret, $id])) {
            header("Location: admin_meniu.php"); // Redirect înapoi la lista
            exit;
        } else {
            $mesaj = "Eroare la actualizare.";
        }
    } else {
        $mesaj = "Toate câmpurile sunt obligatorii.";
    }
}

// 2. PRELUARE DATE PRODUS 
if (isset($_GET['id'])) {
    $stmt = $conn->prepare("SELECT * FROM produse WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $produs = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$produs) { die("Produs inexistent."); }
} else {
    header("Location: admin_meniu.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Editează Produs</title>
    <link rel="stylesheet" href="style.css">
        <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
    <style>
        .edit-form { max-width: 500px; margin: 0 auto; }
        .edit-form label { display: block; margin-top: 15px; font-weight: bold; color: #8b4513; }
        .edit-form input { width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px; }
        .btn-save { background-color: #27ae60; color: white; border: none; padding: 12px; width: 100%; margin-top: 20px; font-size: 1.1em; cursor: pointer; border-radius: 5px;}
        .btn-save:hover { background-color: #219150; }
        .img-preview { display: block; margin: 10px auto; max-width: 200px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    </style>
</head>
<body>

<header>
    <div class="container">
        <h1 class="logo">Editare Produs</h1>
        <nav>
            <ul>
                <li><a href="admin_meniu.php">Renunță</a></li>
            </ul>
        </nav>
    </div>
</header>

<main class="reservation">
    <div class="container reservation-card">
        <h1>Modifică: <?= htmlspecialchars($produs['nume']) ?></h1>
        
        <?php if ($mesaj): ?>
            <p style="color:red; text-align:center;"><?= $mesaj ?></p>
        <?php endif; ?>

        <img src="<?= htmlspecialchars($produs['imagine']) ?>" class="img-preview" alt="Previzualizare">

        <form method="POST" action="" class="edit-form">
            <input type="hidden" name="id" value="<?= $produs['id'] ?>">

            <label>Nume Produs:</label>
            <input type="text" name="nume" value="<?= htmlspecialchars($produs['nume']) ?>" required>

            <label>Preț (Lei):</label>
            <input type="number" name="pret" step="0.01" value="<?= $produs['pret'] ?>" required>

            <button type="submit" class="btn-save">Salvează Modificările</button>
        </form>
    </div>
</main>

</body>
</html>