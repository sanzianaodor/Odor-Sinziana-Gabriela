<?php
session_start();
if (!isset($_SESSION["admin"])) { header("Location: login.html"); exit; }

$host = "mysql"; $db = "studenti"; $user = "user"; $pass = "password";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
} catch (PDOException $e) { die("Err"); }

$id = $_GET['id'] ?? null;
$mesaj = "";

// 1. Daca se trimite formularul de update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $nume = $_POST['nume'];
    $data = $_POST['data'];
    $ora = $_POST['ora'];
    $pers = $_POST['pers'];
    $tel = $_POST['telefon'];

    $stmt = $pdo->prepare("UPDATE rezervari SET nume=?, data_rezervare=?, ora_rezervare=?, numar_persoane=?, telefon=? WHERE id=?");
    if ($stmt->execute([$nume, $data, $ora, $pers, $tel, $id])) {
        header("Location: admin.php"); // Redirect inapoi la lista dupa succes
        exit;
    } else {
        $mesaj = "Eroare la actualizare.";
    }
}

// 2. Selectam datele curente pentru a popula formularul
if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM rezervari WHERE id = ?");
    $stmt->execute([$id]);
    $rezervare = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$rezervare) die("Rezervare inexistenta.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Editează Rezervare</title>
    <link rel="stylesheet" href="style.css">
        <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<main class="reservation">
    <div class="container reservation-card">
        <h1>Editează Rezervarea #<?= $id ?></h1>
        <p style="color:red"><?= $mesaj ?></p>

        <form method="POST" action="">
            <input type="hidden" name="id" value="<?= $rezervare['id'] ?>">
            
            <label>Nume:</label>
            <input type="text" name="nume" value="<?= htmlspecialchars($rezervare['nume']) ?>" required>

            <label>Telefon:</label>
            <input type="text" name="telefon" value="<?= htmlspecialchars($rezervare['telefon']) ?>" required>

            <label>Data:</label>
            <input type="date" name="data" value="<?= $rezervare['data_rezervare'] ?>" required>

            <label>Ora:</label>
            <input type="time" name="ora" value="<?= $rezervare['ora_rezervare'] ?>" required>

            <label>Persoane:</label>
            <input type="text" name="pers" value="<?= $rezervare['numar_persoane'] ?>" required>

            <button type="submit">Salvează Modificările</button>
            <a href="admin.php" style="display:block; text-align:center; margin-top:15px;">Anulează</a>
        </form>
    </div>
</main>
</body>
<a id="top"></a>
<footer>
    <p>&copy; 2025 Casa cu Delicii — Toate drepturile rezervate</p>
</footer>

<a href="#top" class="back-to-top">⬆ Sus</a>
</html>