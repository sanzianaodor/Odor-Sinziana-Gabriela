<?php
session_start();

// 1. Verificam daca utilizatorul e logat
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit;
}

$host = "mysql"; $db = "studenti"; $user = "user"; $pass = "password";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Eroare conexiune."); }

$myId = $_SESSION['user_id'];

// Aflam si emailul pentru verificare (pentru rezervarile vechi)
$stmtUser = $pdo->prepare("SELECT email FROM utilizatori WHERE id = ?");
$stmtUser->execute([$myId]);
$myEmail = $stmtUser->fetchColumn();

$mesaj = "";
$rezervare = null;

// ACTUALIZARE (Cand se apasa butonul Salveaza) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_rez = $_POST['id'];
    $data   = $_POST['data'];
    $ora    = $_POST['ora'];
    $pers   = $_POST['persoane'];

    // Update securizat: Modificam DOAR daca rezervarea apartine userului curent
    $stmt = $pdo->prepare("UPDATE rezervari 
                           SET data_rezervare = ?, ora_rezervare = ?, numar_persoane = ? 
                           WHERE id = ? AND (user_id = ? OR email = ?)");
    
    if ($stmt->execute([$data, $ora, $pers, $id_rez, $myId, $myEmail])) {
        // Mergem inapoi la profil
        header("Location: profil.php");
        exit;
    } else {
        $mesaj = "Eroare la actualizare.";
    }
}

// AFISARE (Preluam datele curente ale rezervarii)
if (isset($_GET['id'])) {
    $id_rez = $_GET['id'];
    
    // Selectam rezervarea doar daca aparține utilizatorului
    $stmt = $pdo->prepare("SELECT * FROM rezervari WHERE id = ? AND (user_id = ? OR email = ?)");
    $stmt->execute([$id_rez, $myId, $myEmail]);
    $rezervare = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$rezervare) {
        die("Nu am găsit această rezervare sau nu ai dreptul să o modifici.");
    }
} else {
    header("Location: profil.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Modifică Rezervarea</title>
    <link rel="stylesheet" href="style.css">
        <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
    <style>

        .edit-form label { display: block; margin-top: 15px; font-weight: bold; color: #8b4513; }
        .edit-form input, .edit-form select { width: 100%; padding: 10px; margin-top: 5px; border-radius: 5px; border: 1px solid #ccc; }
        .btn-save { background-color: #27ae60; color: white; padding: 12px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 1.1em; margin-top: 20px; width: 100%; }
        .btn-save:hover { background-color: #219150; }
        .btn-cancel { display: block; text-align: center; margin-top: 15px; color: #7f8c8d; text-decoration: none; }
    </style>
</head>
<body>

<header>
    <div class="container">
        <h1 class="logo">Modificare Rezervare</h1>
        <nav>
            <ul>
                <li><a href="profil.php">Înapoi la Profil</a></li>
            </ul>
        </nav>
    </div>
</header>

<main class="reservation">
    <div class="container reservation-card" style="max-width: 500px;">
        <h1>Detalii Rezervare</h1>
        
        <?php if ($mesaj): ?>
            <p style="color: red; text-align: center;"><?= $mesaj ?></p>
        <?php endif; ?>

        <form method="POST" action="" class="edit-form">
            <input type="hidden" name="id" value="<?= $rezervare['id'] ?>">

            <p><strong>Nume rezervare:</strong> <?= htmlspecialchars($rezervare['nume']) ?></p>

            <label>Data nouă:</label>
            <input type="date" name="data" value="<?= $rezervare['data_rezervare'] ?>" required>

            <label>Ora nouă:</label>
            <input type="time" name="ora" value="<?= date('H:i', strtotime($rezervare['ora_rezervare'])) ?>" required>

            <label>Număr persoane:</label>
            <select name="persoane" required>
                <option value="1" <?= $rezervare['numar_persoane'] == '1' ? 'selected' : '' ?>>1</option>
                <option value="2" <?= $rezervare['numar_persoane'] == '2' ? 'selected' : '' ?>>2</option>
                <option value="3" <?= $rezervare['numar_persoane'] == '3' ? 'selected' : '' ?>>3</option>
                <option value="4" <?= $rezervare['numar_persoane'] == '4' ? 'selected' : '' ?>>4</option>
                <option value="5" <?= $rezervare['numar_persoane'] == '5' ? 'selected' : '' ?>>5</option>
                <option value="6+" <?= $rezervare['numar_persoane'] == '6+' ? 'selected' : '' ?>>6+</option>
            </select>

            <button type="submit" class="btn-save">Salvează Modificările</button>
            <a href="profil.php" class="btn-cancel">Renunță</a>
        </form>
    </div>
</main>

</body>
<a id="top"></a>
<footer>
    <p>&copy; 2025 Casa cu Delicii — Toate drepturile rezervate</p>
</footer>

<a href="#top" class="back-to-top">⬆ Sus</a>
</html>