<?php
session_start();

// AUTO-LOGOUT (1 ORA) 
$timp_limita = 3600; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timp_limita)) {
    session_unset(); session_destroy();
    header("Location: login.html"); exit;
}
$_SESSION['last_activity'] = time();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Casa cu Delicii</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<a id="top"></a>

<header>
    <div class="container">
        <h1 class="logo">Casa cu Delicii</h1>
        <nav>
    <ul>
        <li><a href="index.php">Acasă</a></li>
        <li><a href="Meniu.php">Meniu</a></li>
        <li><a href="Rezervari.php">Rezervări</a></li>
        <li><a href="Despre.php">Despre</a></li>
        <li><a href="Contact.php">Contact</a></li>

        <?php if (isset($_SESSION['user_id'])): ?>
            <li class="login-item">
                <a href="profil.php" class="btn-login" style="background:#8b4513; color:white!important;">
                    Contul Meu
                </a>
            </li>
        <?php elseif (isset($_SESSION['admin'])): ?>
            <li class="login-item">
                <a href="admin.php" class="btn-login" style="background:#8b4513; color:white!important;">
                    Contul Meu
                </a>
            </li>
        <?php else: ?>
            <li class="login-item">
                <a href="login.html" class="btn-login">
                    Login / Înregistrare
                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>
    </div>
</header>

<main>
<section class="hero">
    <div class="overlay">
        <h2>Bun venit la Casa cu Delicii</h2>
        <p>Experimentează gusturi autentice</p>
        <div id="mesaj-dom"></div> 
        <a href="Meniu.php" class="btn">Vezi meniul</a>
    </div>
</section>

    <section class="about">
        <div class="container">
            <h2>Despre noi</h2>
            <p>La Casa cu Delicii îmbinăm tradiția cu rafinamentul modern, oferind preparate autentice și ingrediente proaspete.</p>
        </div>
    </section>

    <section class="info">
        <div class="container grid">
            <div class="card">
                <h3>Program</h3>
                <p><strong>Luni - Duminică:</strong><br>10:00 - 23:00</p>
            </div>
            <div class="card">
                <h3>Adresa</h3>
                <p>Str. Mioriței nr. 12<br>București, România</p>
            </div>
            <div class="card">
                <h3>Rezervări</h3>
                <p>Sună la <strong>+40721123456</strong> sau <a href="Rezervari.php">rezervă online</a>.</p>
            </div>
        </div>
    </section>

    <section class="gallery">
        <img src="imagini/restaurant.jpg" alt="Restaurant Casa cu Delicii">
    </section>
</main>

<aside>
    <h3>Știri & Promoții</h3>
    <ul>
        <li> Desert al zilei: Cheesecake!</li>
        <li> Muzică live în weekend!</li>
    </ul>
</aside>

<footer>
    <p>&copy; 2025 Casa cu Delicii — Toate drepturile rezervate</p>
</footer>

<a href="#top" class="back-to-top">⬆ Sus</a>
<script src="script.js"></script>
</body>
</html>