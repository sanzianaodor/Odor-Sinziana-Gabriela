<?php
session_start();

$host = "mysql";
$db   = "studenti";
$user = "user";
$pass = "password";

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8",
        $user,
        $pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    error_log($e->getMessage());
    die("Eroare BD"); 
}

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if ($username) {
    $stmt = $pdo->prepare("SELECT parola FROM admini WHERE username = ?");
    $stmt->execute([$username]);
    $userDB = $stmt->fetch();

    if ($userDB && $password == $userDB['parola']) {
        $_SESSION['admin'] = $username;
        header("Location: admin.php");
        exit;
    }
}

echo "Login invalid";
?>