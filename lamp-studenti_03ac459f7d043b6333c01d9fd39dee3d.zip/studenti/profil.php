<?php
session_start();

// 1. AUTO-LOGOUT
$timp_limita = 3600; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timp_limita)) {
    session_unset(); session_destroy(); header("Location: login.html"); exit;
}
$_SESSION['last_activity'] = time();

// 2. VERIFICARE LOGIN
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit;
}

// 3. CONEXIUNE BD
$host = "mysql"; $db = "studenti"; $user = "user"; $pass = "password";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Eroare conexiune BD"); }

$myId = $_SESSION['user_id'];

// Aflam emailul
$stmtUser = $pdo->prepare("SELECT email FROM utilizatori WHERE id = ?");
$stmtUser->execute([$myId]);
$myEmail = $stmtUser->fetchColumn();

// ANULARE (doar pentru rezervari viitoare)
if (isset($_GET['anuleaza_id'])) {
    $stmt = $pdo->prepare("DELETE FROM rezervari WHERE id = ? AND (user_id = ? OR email = ?)");
    $stmt->execute([$_GET['anuleaza_id'], $myId, $myEmail]);
    header("Location: profil.php");
    exit;
}

// SEPARARE REZERVARI

// 1. VIITOARE (Active) - Ordonate Crescator (cele mai apropiate primele)
$sqlViitoare = "SELECT * FROM rezervari 
                WHERE (user_id = ? OR email = ?) 
                AND data_rezervare >= CURDATE() 
                ORDER BY data_rezervare ASC, ora_rezervare ASC";
$stmtV = $pdo->prepare($sqlViitoare);
$stmtV->execute([$myId, $myEmail]);
$rezervariViitoare = $stmtV->fetchAll(PDO::FETCH_ASSOC);

// 2. TRECUTE (Istoric) - Ordonate Descrescator (cele mai recente primele)
$sqlTrecute = "SELECT * FROM rezervari 
               WHERE (user_id = ? OR email = ?) 
               AND data_rezervare < CURDATE() 
               ORDER BY data_rezervare DESC, ora_rezervare DESC";
$stmtT = $pdo->prepare($sqlTrecute);
$stmtT->execute([$myId, $myEmail]);
$rezervariTrecute = $stmtT->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Contul Meu</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
    <style>
        .rezervare-item {
            background: #fff;
            border-left: 5px solid #8b4513; /* Linie Maro default */
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 15px;
            padding: 20px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .rezervare-istoric {
            background: #f9f9f9;
            border-left: 5px solid #bdc3c7; 
            opacity: 0.8;
        }

        .detalii-rezervare strong { color: #8b4513; }
        .actiuni-butoane { display: flex; gap: 10px; }
        
        .btn-anulare { background-color: #d63031; color: white; padding: 8px 15px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 0.9em; transition: background 0.3s; }
        .btn-anulare:hover { background-color: #b71c1c; }
        
        .btn-modifica { background-color: #2980b9; color: white; padding: 8px 15px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 0.9em; transition: background 0.3s; }
        .btn-modifica:hover { background-color: #1f6391; }

        .separator { margin: 40px 0 20px 0; border-top: 2px dashed #ccc; }
        h2.titlu-sectiune { color: #555; margin-bottom: 15px; font-family: 'Cinzel', serif; border-bottom: 2px solid #8b4513; display: inline-block; padding-bottom: 5px;}
        
        .status-badge { padding: 3px 8px; border-radius: 10px; font-size: 0.8em; color: white; font-weight: bold; margin-left: 5px; }
        .st-verde { background-color: #27ae60; }
        .st-rosu { background-color: #c0392b; }
        .st-galben { background-color: #f39c12; }
    </style>
</head>
<body>

<header>
    <div class="container">
        <h1 class="logo">Salut, <?= htmlspecialchars($_SESSION['user_nume']) ?>!</h1>
        <nav>
            <ul>
                <li><a href="index.php">Acasă</a></li>
                <li><a href="Meniu.php">Meniu</a></li>
                <li><a href="Rezervari.php">Rezervă din nou</a></li>
                <li class="login-item">
                    <a href="logout.php" class="btn-login">Delogare</a>
                </li>
            </ul>
        </nav>
    </div>
</header>

<main class="reservation">
    <div class="container reservation-card">
        
        <h2 class="titlu-sectiune">Rezervări Active</h2>
        
        <?php if (count($rezervariViitoare) > 0): ?>
            <div class="lista-rezervari">
                <?php foreach ($rezervariViitoare as $r): 
                     
                     $clasaStatus = 'st-galben';
                     if($r['status'] == 'Confirmat') $clasaStatus = 'st-verde';
                     if($r['status'] == 'Anulat') $clasaStatus = 'st-rosu';
                ?>
                    <div class="rezervare-item">
                        <div class="detalii-rezervare">
                            <p><strong>Nume:</strong> <?= htmlspecialchars($r['nume']) ?></p>
                            <p>
                                <strong>Data:</strong> <?= date("d.m.Y", strtotime($r['data_rezervare'])) ?>
                                | <strong>Ora:</strong> <?= date("H:i", strtotime($r['ora_rezervare'])) ?>
                            </p>
                            <p><strong>Persoane:</strong> <?= htmlspecialchars($r['numar_persoane']) ?></p>
                            <p>
                                <strong>Status:</strong> 
                                <span class="status-badge <?= $clasaStatus ?>"><?= $r['status'] ?></span>
                            </p>
                        </div>
                        <div class="actiuni-butoane">
                            <a href="edit_rezervare_client.php?id=<?= $r['id'] ?>" class="btn-modifica">Modifică</a>
                            <a href="profil.php?anuleaza_id=<?= $r['id'] ?>" class="btn-anulare" onclick="return confirm('Ești sigur că vrei să anulezi?')">Anulează</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="padding:10px;">Nu ai rezervări viitoare programate.</p>
            <a href="Rezervari.php" class="btn" style="margin-top:10px;">Fă o rezervare acum!</a>
        <?php endif; ?>


        <div class="separator"></div>


        <h2 class="titlu-sectiune" style="border-color: #999; color: #777;">Istoric Vizite</h2>
        
        <?php if (count($rezervariTrecute) > 0): ?>
            <div class="lista-rezervari">
                <?php foreach ($rezervariTrecute as $r): ?>
                    <div class="rezervare-item rezervare-istoric">
                        <div class="detalii-rezervare">
                            <p style="color:#555;"><strong>Dată vizită:</strong> <?= date("d.m.Y", strtotime($r['data_rezervare'])) ?></p>
                            <p style="color:#555;"><strong>Oră:</strong> <?= date("H:i", strtotime($r['ora_rezervare'])) ?></p>
                            <p style="color:#555;"><strong>Persoane:</strong> <?= htmlspecialchars($r['numar_persoane']) ?></p>
                            <p style="color:#555;"><strong>Status final:</strong> <?= $r['status'] ?></p>
                        </div>
                        <div class="actiuni-butoane">
                            <span style="color: #999; font-size: 0.9em; font-style: italic;">Finalizat</span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="color: gray; padding:10px;">Nu ai nicio rezervare în istoric.</p>
        <?php endif; ?>

    </div>
</main>

</body>
<a id="top"></a>
<footer>
    <p>&copy; 2025 Casa cu Delicii — Toate drepturile rezervate</p>
</footer>

<a href="#top" class="back-to-top">⬆ Sus</a>
</html>