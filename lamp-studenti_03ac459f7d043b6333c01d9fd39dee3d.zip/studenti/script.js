document.addEventListener("DOMContentLoaded", function() {

    const containerMesaj = document.getElementById("mesaj-dom");

    if (containerMesaj) {
        const ora = new Date().getHours();
        let textMesaj = "";
        let iconita = "";

        // Alegem mesajul in functie de ora
        if (ora < 12) {
            textMesaj = "Bună dimineața! Cafeaua te așteaptă.";
        } else if (ora < 18) {
            textMesaj = "Vino să încerci meniul nostru de prânz!";
        } else {
            textMesaj = "Te așteptăm la o cină relaxantă!";
        }

        // Scriem textul în pagina HTML
        containerMesaj.innerHTML = `<strong>${iconita} ${textMesaj}</strong>`;
        
        // Adaugam stilizare direct din JS
        containerMesaj.style.color = "#ffffffff"; 
        containerMesaj.style.fontSize = "1.2em";
        
        containerMesaj.style.marginTop = "20px";
        containerMesaj.style.marginBottom = "30px";
        containerMesaj.style.display = "block"; 
    } 


    const forms = document.querySelectorAll("form");
    
    forms.forEach(function(form) {
  
    if (
        form.id === "formularRezervareClient" ||
        form.action.includes("login.php") ||
        form.classList.contains("contact-form")
    ) {
        return;
    }

    form.addEventListener("submit", function(e) {
        e.preventDefault();

        const numeInput = form.querySelector("input[name='name']");
        const nume = numeInput ? numeInput.value : "Oaspete";

        alert(`Mulțumim, ${nume}! Solicitarea a fost trimisă cu succes.`);
        form.reset();
    });
});



    const footerText = document.querySelector("footer p");
    if (footerText) {
        const anCurent = new Date().getFullYear();
        footerText.innerHTML = `&copy; ${anCurent} Casa cu Delicii — Toate drepturile rezervate`;
    }
});
