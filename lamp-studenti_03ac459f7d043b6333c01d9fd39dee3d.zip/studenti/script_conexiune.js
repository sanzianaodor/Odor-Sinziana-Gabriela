const API_URL = 'api_rezervare.php'; 

document.getElementById('formularRezervareClient').addEventListener('submit', function(event) {
    event.preventDefault();

    const form = event.target;
    const statusElement = document.getElementById('statusRezervare');
    const submitBtn = form.querySelector('button[type="submit"]');

    // 1. Dezactivam butonul sa nu se poata apasa de 2 ori
    submitBtn.disabled = true;
    submitBtn.textContent = "Se trimite...";
    
    statusElement.textContent = 'Procesare...';
    statusElement.style.color = '#3498db';

    const formData = new FormData(form);
    
    fetch(API_URL, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // 2. Folosim "mesaj" (cum vine din PHP)
        if (data.status === 'success') {
            statusElement.textContent = data.mesaj; 
            statusElement.style.color = 'green';
            form.reset(); 
            // Reactivam butonul dupa 3 secunde 
            setTimeout(() => { 
                submitBtn.disabled = false; 
                submitBtn.textContent = "Rezervă acum";
            }, 3000);
        } else {
            statusElement.textContent = 'Eroare: ' + data.mesaj;
            statusElement.style.color = 'red';
            submitBtn.disabled = false;
            submitBtn.textContent = "Rezervă acum";
        }
    })
    .catch(error => {
        console.error('Eroare:', error);
        statusElement.textContent = 'Eroare de comunicare.';
        submitBtn.disabled = false;
        submitBtn.textContent = "Rezervă acum";
    });
});