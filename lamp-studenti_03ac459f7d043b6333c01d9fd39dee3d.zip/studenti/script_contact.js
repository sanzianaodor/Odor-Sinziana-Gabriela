const API_CONTACT_URL = 'api_contact.php'; 

document.getElementById('formularContact').addEventListener('submit', function(event) {
    event.preventDefault(); // Opreste reincarcarea paginii

    const form = event.target;
    const statusElement = document.getElementById('statusContact');
    const btnSubmit = form.querySelector('button[type="submit"]');

    statusElement.textContent = 'Se trimite mesajul...';
    statusElement.style.color = '#3498db';
    btnSubmit.disabled = true;

    const formData = new FormData(form);
    
    fetch(API_CONTACT_URL, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            statusElement.textContent = data.mesaj; 
            statusElement.style.color = 'green';
            form.reset(); 
        } else {
            statusElement.textContent = 'Eroare: ' + data.mesaj;
            statusElement.style.color = 'red';
        }
    })
    .catch(error => {
        console.error('Eroare:', error);
        statusElement.textContent = 'Eroare de conexiune.';
        statusElement.style.color = 'red';
    })
    .finally(() => {
        btnSubmit.disabled = false;
    });
});