-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: studenti
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admini`
--

DROP TABLE IF EXISTS `admini`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admini` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parola` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admini`
--

LOCK TABLES `admini` WRITE;
/*!40000 ALTER TABLE `admini` DISABLE KEYS */;
INSERT INTO `admini` VALUES (1,'admin','admin123');
/*!40000 ALTER TABLE `admini` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mesaje`
--

DROP TABLE IF EXISTS `mesaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mesaje` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subiect` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mesaj` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_trimitere` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mesaje`
--

LOCK TABLES `mesaje` WRITE;
/*!40000 ALTER TABLE `mesaje` DISABLE KEYS */;
INSERT INTO `mesaje` VALUES (1,'Tudor Radu','tudorradu@gmail.com','Feedback','Mancarea a fost foarte buna!','2026-01-13 13:36:28');
/*!40000 ALTER TABLE `mesaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produse`
--

DROP TABLE IF EXISTS `produse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pret` decimal(10,2) NOT NULL,
  `imagine` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categorie` enum('antreu','fel_principal','desert') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produse`
--

LOCK TABLES `produse` WRITE;
/*!40000 ALTER TABLE `produse` DISABLE KEYS */;
INSERT INTO `produse` VALUES (1,'Bruschete cu roșii și busuioc',21.00,'imagini/bruschete.jpg','antreu'),(2,'Platou de brânzeturi',35.00,'imagini/branzeturi.jpg','antreu'),(3,'Supă cremă de legume',18.00,'imagini/supa_crema.jpg','antreu'),(4,'Pui la grătar cu legume',38.00,'imagini/pui_cu_legume.jpg','fel_principal'),(5,'Somon la cuptor cu orez sălbatic',55.00,'imagini/somon.jpg','fel_principal'),(6,'Paste Carbonara',32.00,'imagini/paste.jpg','fel_principal'),(7,'Tiramisu',22.00,'imagini/tiramisu.jpg','desert'),(8,'Clătite cu dulceață de casă',18.00,'imagini/clatite.jpg','desert'),(9,'Cheesecake cu fructe de pădure',25.00,'imagini/cheesecake.jpg','desert');
/*!40000 ALTER TABLE `produse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rezervari`
--

DROP TABLE IF EXISTS `rezervari`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rezervari` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefon` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_rezervare` date NOT NULL,
  `ora_rezervare` time NOT NULL,
  `numar_persoane` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT NULL,
  `status` enum('În așteptare','Confirmat','Anulat') COLLATE utf8mb4_unicode_ci DEFAULT 'În așteptare',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rezervari`
--

LOCK TABLES `rezervari` WRITE;
/*!40000 ALTER TABLE `rezervari` DISABLE KEYS */;
INSERT INTO `rezervari` VALUES (1,'Garbea Denisa','garbead46@gmail.com','0735462738','2026-01-12','12:40:00','2','2026-01-06 11:54:55',NULL,'Confirmat'),(6,'Tudor Radu','tudorradu@gmail.com','0745362739','2026-02-14','18:00:00','2','2026-01-06 12:05:04',NULL,'Confirmat'),(7,'Popa Maria','mariapopa@gmail.com','0749283647','2026-02-02','16:30:00','4','2026-01-06 18:08:29',2,'Anulat'),(9,'Lupu Iulia','iulialupu@gmail.com','0742654879','2026-01-20','19:00:00','1','2026-01-20 12:51:00',NULL,'Confirmat');
/*!40000 ALTER TABLE `rezervari` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilizatori`
--

DROP TABLE IF EXISTS `utilizatori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilizatori` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parola` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_inregistrare` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilizatori`
--

LOCK TABLES `utilizatori` WRITE;
/*!40000 ALTER TABLE `utilizatori` DISABLE KEYS */;
INSERT INTO `utilizatori` VALUES (1,'Garbea Denisa','garbead46@gmail.com','$2y$10$rQwcPIdoDOinomzZzfvu7OqGlPdNBmgmyqhzBM13U4W8I532gvyCe','2026-01-06 12:15:16'),(2,'Popa Maria','mariapopa@gmail.com','$2y$10$Ae5E5Ifo0oRuSyCwxKDdhORzg88kMyie5yio.VwkuxbMni8UDpyuO','2026-01-06 18:02:53'),(3,'Odor Adrian','odoradrian@yahoo.com','$2y$10$S.eR90D/QisCR7hQ/zDOJ.j.7DdXZKucoPdPLHqnaVnO5xczaZZVe','2026-01-06 18:27:47'),(4,'Sanziana Odor','sanzianaodor@gmail.com','$2y$10$pu9ZhtBGrDdx..DSaKDCSeEZ9JFqtuo9ti2YEzg4J/rhoNLXSV2bm','2026-01-20 12:09:44');
/*!40000 ALTER TABLE `utilizatori` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-20 15:36:16
